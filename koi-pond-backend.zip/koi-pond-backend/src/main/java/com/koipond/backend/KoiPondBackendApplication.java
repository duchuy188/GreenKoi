package com.koipond.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KoiPondBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(KoiPondBackendApplication.class, args);
	}

}
