package com.koipond.backend.dto;

import lombok.Data;

@Data
public class RejectDesignRequest {
    private String rejectionReason;
}