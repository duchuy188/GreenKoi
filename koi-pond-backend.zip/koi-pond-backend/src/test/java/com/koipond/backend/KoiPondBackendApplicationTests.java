package com.koipond.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KoiPondBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
