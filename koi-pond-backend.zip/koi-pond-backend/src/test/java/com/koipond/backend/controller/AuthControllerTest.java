package com.koipond.backend.controller;

public class AuthControllerTest {
}
