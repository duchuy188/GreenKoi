package com.koipond.backend.controller;

public class AuthControllerApiTest {
    
}
